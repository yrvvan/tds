<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="PGASCOM">
    <meta name="keyword" content="#">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restricted Area</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/bootstrap/css/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/js/DataTables/media/css/jquery.dataTables.css" rel="stylesheet" />
    <!--external css-->
    <link href="<?php echo base_url(); ?>assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>assets/css/fileupload.css" rel="stylesheet" />

    <!--<link rel="stylesheet" type="text/css" href="assets/bootstrap-datepicker/css/datepicker.css" />->

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>assets/css/adm/style.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/adm/style-responsive.css" rel="stylesheet" />

</head>