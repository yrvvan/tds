<footer class="site-footer">
    <div class="text-center">
        2016 &copy; PGASCOM | PGN.
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>