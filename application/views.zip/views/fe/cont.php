<div class="col-md-4 col-sm-6 pre-footer-col">
    <h2>Kontak Kami</h2>
    <address class="margin-bottom-40">
        35, Lorem Lis Street, Park Ave<br>
        Jakarta, ID<br>
        Phone: 300 323 3456<br>
        Fax: 300 323 1456<br>
        Email: info@pgn.com<br>
    </address>

    <div class="pre-footer-subscribe-box pre-footer-subscribe-box-vertical">
        <h2>Berlangganan</h2>
        <p>Subscribe to our newsletter and stay up to date with the latest news and deals!</p>
        <form action="<?php echo base_url() . "Cruno/subscribe"; ?>" method="post">
            <div class="input-group">
                <input type="email" placeholder="youremail@mail.com" class="form-control" name="email" autocomplete="off">
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit">Subscribe</button>
                </span>
            </div>
        </form>
    </div>
</div>