<?php $this->load->view('fe/sld'); ?>

<div class="main">
    <div class="container">
        <?php $this->load->view('fe/vimi'); ?>
        <?php $this->load->view('fe/evn'); ?>
        <?php $this->load->view('fe/art'); ?>
        <?php $this->load->view('fe/slog'); ?>
        <?php $this->load->view('fe/cli'); ?>
    </div>
</div>