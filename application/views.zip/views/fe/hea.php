<div class="header">
    <div class="container">
        <a class="site-logo" href="#"><img src="<?php echo base_url() ?>assets/img/logo.png"></a>

        <a href="javascript:void(0);" class="mobi-toggler"><i class="fa fa-bars"></i></a>

        <?php $this->load->view('fe/nav'); ?>
    </div>
</div>