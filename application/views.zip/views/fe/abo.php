<div class="col-md-4 col-sm-6 pre-footer-col">
    <h2>Tentang Kami</h2>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam sit nonummy nibh euismod tincidunt ut laoreet dolore magna aliquarm erat sit volutpat.</p>
</div>