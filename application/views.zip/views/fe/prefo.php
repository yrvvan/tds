<div class="pre-footer">
    <div class="container">
        <div class="row">
            <?php $this->load->view('fe/abo'); ?>
            <?php $this->load->view('fe/cont'); ?>
            <?php $this->load->view('fe/twi'); ?>
        </div>
    </div>
</div>