<div class="row mix-block margin-bottom-40">
    <?php $this->load->view('fe/tab'); ?>
    <?php $this->load->view('fe/testi'); ?>
</div>